create procedure showTable()
begin
select * from student;
end;

